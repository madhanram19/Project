import React, { Component, Fragment, useState, useRef, useEffect, createRef  } from "react";
import ReactDOM from "react-dom";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import { useNavigate } from 'react-router-dom';
import { Container, Input, Dropdown, UncontrolledDropdown, DropdownToggle, DropdownMenu, DropdownItem, UncontrolledCollapse, TabContent, Modal, ModalHeader, ModalBody, TabPane, Nav, NavItem, NavLink, Collapse, Navbar} from 'reactstrap';
import logo from '../../assets/images/logo.png';
import { Link } from 'react-router-dom';
import metamask from '../../assets/images/MetaMask.svg';
import logoInr from '../../assets/images/logo.png';
import mdlCloseIcon from '../../assets/images/mdl-close-icon.svg';
import Web3 from "web3";



const Header = (props) => {
    const navigate = useNavigate();
    const user = localStorage.getItem('token');

    const [address, setAddress] = useState("");
    const [balance, setBalance] = useState(0);
    const [web3, setWeb3] = useState(null);
    const [block, setBlock] = useState();
    const [currentAccount, setCurrentAccount] = useState(null);
    const [isActive, setActive] = useState("false");
    const [toggleNav, setTogglenave]= useState();
    const [ isOpen, setIsOpen]= useState();

   const ToggleClass = () => {
    setActive(!isActive);
  };
  const [modal, setModal] = useState(false);
  const toggle = () => setModal(!modal);
    // const [scroll, setScroll] = useState(false);
    // useEffect(() => {
    // window.addEventListener("scroll", () => {
    // setScroll(window.scrollY > 50);
    // });
    // }, []);

    const handleAllActions = async () => {
        try {
          console.log("Requesting accounts...");
          const accounts = await window.ethereum.request({
            method: "eth_requestAccounts"
          });
          console.log("Connected accounts:", accounts);
          setAddress(accounts);
          setCurrentAccount(accounts[0]);
    
          if (accounts.length > 0) {
            web3.eth.getBalance(accounts[0]).then((balance) => {
              const balanceInEther = web3.utils.fromWei(balance, "ether");
              console.log("Balance in Ether:", balanceInEther);
              setBalance(balanceInEther);
            });
          } else {
            console.error("MetaMask not connected. Please connect your wallet.");
          }
          console.log("Switching network...");
          await window.ethereum.request({
            method: "wallet_switchEthereumChain",
            params: [
              {
                chainId: "0x38"
              }
            ]
          });
    
          console.log("Network switched successfully.");
    
          console.log("Fetching block number...");
          const blockNumber = await web3.eth.getBlockNumber();
          console.log("Block number:", blockNumber);
          setBlock(blockNumber);
    
          if (!currentAccount) {
            alert("Please connect your wallet first.");
            return;
          }
          console.log("Interacting with the contract...");
          //const contractResult = await interactWithContract();
          //console.log("Contract interaction result:", contractResult);
        } catch (error) {
          console.error("Error in handleAllActions:", error);
        }
      };

      const logout = () => {
        localStorage.removeItem("token");
        navigate("/Login");
      };


    return (
        <Fragment>
            <header className="HddrBg FxdHeader">
                <nav className="navbar navbar-expand-lg">
                    <div className="container container-1200">
                        <div className="logo_header">
                            <a href="/" className=""><img src={logo} className="img-fluid" alt="bowo" /></a>
                        </div>
                        <button type="button" onClick={toggleNav} className="plate navbar-toggle CollBTn collapsed sm-only ui">
                            <svg onClick={ToggleClass} className={isActive ? "ham hamRotate ham8" : "ham hamRotate ham8 active"} viewBox="0 0 100 100" width="60" >
                                <path
                                    className="line top"
                                    d="m 30,33 h 40 c 3.722839,0 7.5,3.126468 7.5,8.578427 0,5.451959 -2.727029,8.421573 -7.5,8.421573 h -20" />
                                <path
                                    className="line middle"
                                    d="m 30,50 h 40" />
                                <path
                                    className="line bottom"
                                    d="m 70,67 h -40 c 0,0 -7.5,-0.802118 -7.5,-8.365747 0,-7.563629 7.5,-8.634253 7.5,-8.634253 h 20" />
                            </svg>
                        </button>
                        <Collapse isOpen={isOpen} navbar className="CllpsMenu w-100">
                            <ul className="navbar-nav mx-auto HddrLnks HdrSroll">
                                <li className="nav-item">
                                    <a className="nav-link" href="/">Home</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="">Stake</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="">Bonding</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="">Governance</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="#">Neo Banking</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="#">FAQ</a>
                                </li>
                            </ul>
                            <div className="HddrBtns ml-xl-5 mb-3 mb-lg-0">
                            {/* <Link className="btn BtnPrimry Btn120-42" style={{color:'black'}} to="/login">
                                Login
                            </Link> */}
                            {user ? (
                  // Render logout button when user is logged in
                  <button
                    className="btn BtnPrimry Btn120-42"  style={{color:'black'}}
                    onClick={() => logout()}
                  // Handle logout logic here 
                  >
                    Logout
                  </button>
                ) : (
                  // Render register and login buttons when user is not logged in
                  <>
                    {/* <Link className="nav-button p-2 text-decoration-none" to="/Register" style={{color:'white'}}>
                      Register
                    </Link> */}
                    <Link className="btn BtnPrimry Btn120-42" to="/Login" style={{color:'black'}}>
                      Login
                    </Link>
                  </>
                )}
                            </div>
                            <div className="HddrBtns ml-xl-5 mb-3 mb-lg-0">
                            {/* <a href="#" class="btn BtnPrimry mr-3 Btn160-42" >Connect Wallet</a> */}
                            <Link className="btn BtnPrimry Btn120-42" onClick={toggle} style={{color:'black'}} to="/">
                                Connect Wallet
                            </Link>
                              </div>
                        </Collapse>
                        <Modal isOpen={modal} toggle={toggle} modalClassName="fade CmmnMdl ClaimMdl" className="modal-dialog-centered">
        <div className="BluBg107 ClaimMdlSec mb-4">
          <div className="BwCloseIcn">
            <button className="btn btn-link close" type="button" onClick={toggle}><img src={mdlCloseIcon} alt="" className="img-fluid" /> </button>
          </div>
          <div className="ClmRwrdHdd mb-4 text-center">
            <h5>Connect Wallet</h5>
          </div>
          <div className="StkBlnDtlsFlx d-block">
            <div className="StkBlnDtls1">
              <img src={metamask} className="img-fluid d-block mx-auto" />
              <p className="text-center" style={{ marginTop: '-25px' }}>Metamask</p>
              <button onClick={handleAllActions} className="btn BtnPrimry Btn120-42 center" style={{ marginLeft:'80px'}}>
                       Connect
              </button>
            </div>
          </div>
        </div>
      </Modal>
                    </div>
                </nav>
            </header>       
        </Fragment>
    );
   
}

export default Header;